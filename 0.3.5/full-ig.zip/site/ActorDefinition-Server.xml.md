# PH Core Server - XML Representation - Draft PH Core Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PH Core Server**

## : PH Core Server - XML Representation

| |
| :--- |
| Draft as of 2026-05-27 |

[Raw xml](ActorDefinition-Server.xml) | [Download](ActorDefinition-Server.xml)

