# Home - Draft PH Core Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://doh.gov.ph/fhir/ph-core/ImplementationGuide/fhir.ph.core | *Version*:0.2.0 |
| Draft as of 2026-04-10 | *Computable Name*:PHCoreImplementationGuide |

# Draft Philippine Core FHIR Implementation Guide (PH Core IG)

> **Project Status: In Development**
 This Implementation Guide is under active development and is not yet available for public or production use. Content, data models, and implementation details are subject to change.

The Philippine Core FHIR Implementation Guide (PH Core IG) defines the nationally agreed core clinical and administrative data standards for interoperable health information exchange in the Philippines. It provides a common, implementable foundation for health systems to consistently exchange data using the HL7® FHIR® standard.

PH Core IG sits between the PH Base IG (foundational national rules) and program- or use case–specific IGs (such as the NHDR IG). It standardizes commonly used FHIR profiles, extensions, terminology bindings, and conformance expectations that are applicable across health programs, facilities, and systems nationwide.

# Project Background

PH Core is actively being developed by UP Manila National TeleHealth Center, under the guidance of the Phillippines Department of Health, with technical assistance from CSIRO Australia.

The initial draft of IG will be tested in the Connectathon to validate proof of concept and direction settings for the Philippines Core IG development process.

# Purpose and Scope

The PH Core IG aims to:

1. Promote nationwide consistency and interoperability of health data
1. Support alignment with national policies such as JAO 2021-0002
1. Enable reuse of HL7 and international FHIR artifacts
1. Provide clear, testable specifications for system implementers

This guide focuses on core clinical and administrative resources (e.g., Patient, Practitioner, Organization, Encounter, Observation) that are widely applicable across multiple use cases. It does not define program-specific workflows or reporting payloads, which are addressed by downstream Implementation Guides.

# Usage of this Guide

* Health information systems implement PH Core profiles as a baseline for interoperability
* Program-specific IGs inherit from PH Core and apply additional constraints
* Developers and vendors use the guide to build and validate FHIR-conformant systems
* Policy and governance bodies use it as a reference for national standardization

# Development and Governance

The PH Core IG is developed through a collaborative, open, and standards-based process, involving the Department of Health (DOH), PhilHealth, UP Manila, and key technical partners. Development follows international best practices, uses open-source tooling (FHIR Shorthand, GitHub, IG Publisher), and is governed through structured review and change control mechanisms.

# Relationship with other IGs

**PH Core:**

* defines a set of conformance requirements that enforce a set of ‘minimum requirements’ on the local concepts, specifying rules for the elements, extensions, vocabularies, and value sets, and the RESTful API interactions.
* for use by the stakeholders in the Philippines when implementing FHIR to provide a common implementation and to be built upon when creating further profiles and implementation guides.
* conformance may become tied to regulatory and/or contractual agreements in order to necessitate adoption to this more prescriptive specification.

The context of PH Core within the set of FHIR Standards is shown in the diagram below.

# Usage

PH Core is particularly useful in defining:

* A testable level of system conformance
* Assumed support by client applications
* The basis of downstream implementation guides

Implementation of capabilities defined in PH Core enables specifications, applications and business logic to be developed with confidence.

This document is a working specification that may be directly implemented by FHIR®© system producers.

FHIR®© Connectathon events are key to the verification of the guide as being suitable for implementation. This implementation guide will be used as the basis for the Philippines Connectathon events.

# Dependencies

This publication includes IP covered under the following statements.

* ISO

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](https://tx.hl7.org.au/fhir/ValueSet/ISO3166Part1): [Barangay](StructureDefinition-barangay.md), [Barangays](ValueSet-barangays.md)... Show 60 more, [Bundle/transaction-example](Bundle-transaction-example.md), [Cities](ValueSet-cities.md), [CityMunicipality](StructureDefinition-city-municipality.md), [Consumer](ActorDefinition-Consumer.md), [Creator](ActorDefinition-Creator.md), [DOHNHFRCode](NamingSystem-DOHNHFRCodeNS.md), [DOHProcedureID](NamingSystem-DOHProcedureIDNS.md), [DrugsVS](ValueSet-drugs-vs.md), [EducationalAttainment](StructureDefinition-educational-attainment.md), [EducationalAttainments](ValueSet-educational-attainments.md), [IndigenousGroup](StructureDefinition-indigenous-group.md), [IndigenousGroupsCS](CodeSystem-indigenous-groups-cs.md), [IndigenousGroupsVS](ValueSet-indigenous-groups-vs.md), [IndigenousPeople](StructureDefinition-indigenous-people.md), [Occupation](StructureDefinition-occupation.md), [OccupationClassifications](ValueSet-occupational-classifications.md), [PHCoreAddress](StructureDefinition-ph-core-address.md), [PHCoreCondition](StructureDefinition-ph-core-condition.md), [PHCoreDOHNHFRCode](StructureDefinition-ph-core-doh-nhfr-code.md), [PHCoreEncounter](StructureDefinition-ph-core-encounter.md), [PHCoreImmunization](StructureDefinition-ph-core-immunization.md), [PHCoreImplementationGuide](index.md), [PHCoreLocation](StructureDefinition-ph-core-location.md), [PHCoreMedication](StructureDefinition-ph-core-medication.md), [PHCoreMedicationAdministration](StructureDefinition-ph-core-medicationadministration.md), [PHCoreMedicationDispense](StructureDefinition-ph-core-medicationdispense.md), [PHCoreMedicationRequest](StructureDefinition-ph-core-medicationrequest.md), [PHCoreMedicationStatement](StructureDefinition-ph-core-medicationstatement.md), [PHCoreName](StructureDefinition-ph-core-name.md), [PHCoreObservation](StructureDefinition-ph-core-observation.md), [PHCoreOrganization](StructureDefinition-ph-core-organization.md), [PHCorePatient](StructureDefinition-ph-core-patient.md), [PHCorePhilHealthID](StructureDefinition-ph-core-philhealth-id.md), [PHCorePhilHealthPAN](StructureDefinition-ph-core-philhealth-pan.md), [PHCorePhilHealthPEN](StructureDefinition-ph-core-philhealth-pen.md), [PHCorePhilSysID](StructureDefinition-ph-core-philsys-id.md), [PHCorePractitioner](StructureDefinition-ph-core-practitioner.md), [PHCorePractitionerRole](StructureDefinition-ph-core-practitionerrole.md), [PHCoreProcedure](StructureDefinition-ph-core-procedure.md), [PHCoreProvenance](StructureDefinition-ph-core-provenance.md), [PHCoreRelatedPerson](StructureDefinition-ph-core-relatedperson.md), [PHCoreServiceRequest](StructureDefinition-ph-core-serviceRequest.md), [PHCoreTask](StructureDefinition-ph-core-task.md), [PHFDACPRCS](CodeSystem-PHFDACPRCS.md), [PSCED](CodeSystem-PSCED.md), [PSGC](CodeSystem-PSGC.md), [PSOC](CodeSystem-PSOC.md), [Patient/example-patient](Patient-example-patient.md), [Patient/patient-single-example](Patient-patient-single-example.md), [PhilHealthID](NamingSystem-PhilHealthIDNS.md), [PhilHealthPAN](NamingSystem-PhilHealthPANNS.md), [PhilHealthPEN](NamingSystem-PhilHealthPENNS.md), [PhilHealthProcedureID](NamingSystem-PhilHealthProcedureIDNS.md), [PhilSysID](NamingSystem-PhilSysIDNS.md), [Province](StructureDefinition-province.md), [Provinces](ValueSet-provinces.md), [Race](StructureDefinition-race.md), [Region](StructureDefinition-region.md), [Regions](ValueSet-regions.md) and [Server](ActorDefinition-Server.md)


* The Unified Code for Units of Measure (UCUM) Copyright © 1999-2020 Regenstrief Institute, Inc. and The UCUM Organization, Indianapolis, IN. All rights reserved. * This table of examples does not include all possible UCUM codes. It includes the most common codes needed for routine laboratory and clinical measures but is not meant to be a comprehensive list. See [http://unitsofmeasure.org](http://unitsofmeasure.org) for the full UCUM specification. This table was compiled by the National Library of Medicine, National Institutes of Health, U.S. Department of Health and Human Services with content contributions from Intermountain Healthcare and the Regenstrief Institute, and is currently maintained by the Regenstrief Institute.

* [UCUM Fragment of common codes](https://tx.hl7.org.au/fhir/ValueSet/unitsofmeasure): [Bundle/transaction-example](Bundle-transaction-example.md), [Immunization/example-immunization](Immunization-example-immunization.md)... Show 6 more, [Immunization/immunization-single-example](Immunization-immunization-single-example.md), [MedicationAdministration/medicationadministration-single-example](MedicationAdministration-medicationadministration-single-example.md), [MedicationDispense/medicationdispense-single-example](MedicationDispense-medicationdispense-single-example.md), [MedicationRequest/medicationrequest-single-example](MedicationRequest-medicationrequest-single-example.md), [Observation/blood-pressure](Observation-blood-pressure.md) and [Observation/observation-single-example](Observation-observation-single-example.md)


* These codes are excerpted from ASTM Standard, E1762-95(2013) - Standard Guide for Electronic Authentication of Health Care Information, Copyright by ASTM International, 100 Barr Harbor Drive, West Conshohocken, PA 19428. Copies of this standard are available through the ASTM Web Site at www.astm.org.

* [Signature Type Codes](http://hl7.org/fhir/R4/codesystem-signature-type.html): [Provenance/provenance-single-example](Provenance-provenance-single-example.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* LOINC: [Bundle/transaction-example](Bundle-transaction-example.md), [Observation/blood-pressure](Observation-blood-pressure.md) and [Observation/observation-single-example](Observation-observation-single-example.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/allergy-single-example](AllergyIntolerance-allergy-single-example.md), [AllergyIntolerance/example-allergy](AllergyIntolerance-example-allergy.md)... Show 12 more, [Bundle/transaction-example](Bundle-transaction-example.md), [Condition/condition-single-example](Condition-condition-single-example.md), [Condition/example-condition](Condition-example-condition.md), [Medication/medication-single-example](Medication-medication-single-example.md), [MedicationDispense/medicationdispense-single-example](MedicationDispense-medicationdispense-single-example.md), [MedicationRequest/medicationrequest-single-example](MedicationRequest-medicationrequest-single-example.md), [MedicationStatement/medicationstatement-single-example](MedicationStatement-medicationstatement-single-example.md), [Observation/blood-pressure](Observation-blood-pressure.md), [Observation/observation-single-example](Observation-observation-single-example.md), [Procedure/procedure-single-example](Procedure-procedure-single-example.md), [ServiceRequest/servicerequest-single-example](ServiceRequest-servicerequest-single-example.md) and [Task/task-single-example](Task-task-single-example.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/allergy-single-example](AllergyIntolerance-allergy-single-example.md), [AllergyIntolerance/example-allergy](AllergyIntolerance-example-allergy.md) and [Bundle/transaction-example](Bundle-transaction-example.md)
* [Condition Category Codes](http://terminology.hl7.org/7.0.0/CodeSystem-condition-category.html): [Condition/condition-single-example](Condition-condition-single-example.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.0/CodeSystem-condition-clinical.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Condition/condition-single-example](Condition-condition-single-example.md) and [Condition/example-condition](Condition-example-condition.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.0.0/CodeSystem-condition-ver-status.html): [Condition/condition-single-example](Condition-condition-single-example.md)
* [Immunization Funding Source](http://terminology.hl7.org/7.0.0/CodeSystem-immunization-funding-source.html): [Immunization/example-immunization](Immunization-example-immunization.md) and [Immunization/immunization-single-example](Immunization-immunization-single-example.md)
* [MedicationDispense Performer Function Codes](http://terminology.hl7.org/7.0.0/CodeSystem-medicationdispense-performer-function.html): [MedicationDispense/medicationdispense-single-example](MedicationDispense-medicationdispense-single-example.md)
* [Observation Category Codes](http://terminology.hl7.org/7.0.0/CodeSystem-observation-category.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Observation/blood-pressure](Observation-blood-pressure.md) and [Observation/observation-single-example](Observation-observation-single-example.md)
* [Provenance participant type](http://terminology.hl7.org/7.0.0/CodeSystem-provenance-participant-type.html): [PHCoreProvenance](StructureDefinition-ph-core-provenance.md) and [Provenance/provenance-single-example](Provenance-provenance-single-example.md)
* [contactRole2](http://terminology.hl7.org/7.0.0/CodeSystem-v2-0131.html): [PHCorePatient](StructureDefinition-ph-core-patient.md)
* [providerRole](http://terminology.hl7.org/7.0.0/CodeSystem-v2-0443.html): [Immunization/example-immunization](Immunization-example-immunization.md), [Immunization/immunization-single-example](Immunization-immunization-single-example.md) and [MedicationAdministration/medicationadministration-single-example](MedicationAdministration-medicationadministration-single-example.md)
* [ActCode](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ActCode.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Encounter/encounter-single-example](Encounter-encounter-single-example.md) and [Encounter/example-encounter](Encounter-example-encounter.md)
* [ActReason](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ActReason.html): [Provenance/provenance-single-example](Provenance-provenance-single-example.md)
* [ActSite](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ActSite.html): [Immunization/example-immunization](Immunization-example-immunization.md) and [Immunization/immunization-single-example](Immunization-immunization-single-example.md)
* [DataOperation](http://terminology.hl7.org/7.0.0/CodeSystem-v3-DataOperation.html): [Provenance/provenance-single-example](Provenance-provenance-single-example.md)
* [MaritalStatus](http://terminology.hl7.org/7.0.0/CodeSystem-v3-MaritalStatus.html): [PHCorePatient](StructureDefinition-ph-core-patient.md)
* [NullFlavor](http://terminology.hl7.org/7.0.0/CodeSystem-v3-NullFlavor.html): [PHCorePatient](StructureDefinition-ph-core-patient.md)
* [ObservationInterpretation](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ObservationInterpretation.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Observation/blood-pressure](Observation-blood-pressure.md) and [Observation/observation-single-example](Observation-observation-single-example.md)
* [ParticipationType](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ParticipationType.html): [Encounter/encounter-single-example](Encounter-encounter-single-example.md)
* [Race](http://terminology.hl7.org/7.0.0/CodeSystem-v3-Race.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Patient/example-patient](Patient-example-patient.md), [Patient/patient-single-example](Patient-patient-single-example.md) and [Race](StructureDefinition-race.md)
* [Religious Affiliation](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ReligiousAffiliation.html): [Bundle/transaction-example](Bundle-transaction-example.md), [Patient/example-patient](Patient-example-patient.md) and [Patient/patient-single-example](Patient-patient-single-example.md)
* [RoleCode](http://terminology.hl7.org/7.0.0/CodeSystem-v3-RoleCode.html): [PHCorePatient](StructureDefinition-ph-core-patient.md) and [RelatedPerson/relatedperson-single-example](RelatedPerson-relatedperson-single-example.md)
* [RouteOfAdministration](http://terminology.hl7.org/7.0.0/CodeSystem-v3-RouteOfAdministration.html): [Immunization/example-immunization](Immunization-example-immunization.md), [Immunization/immunization-single-example](Immunization-immunization-single-example.md), [MedicationAdministration/medicationadministration-single-example](MedicationAdministration-medicationadministration-single-example.md), [MedicationRequest/medicationrequest-single-example](MedicationRequest-medicationrequest-single-example.md) and [MedicationStatement/medicationstatement-single-example](MedicationStatement-medicationstatement-single-example.md)


This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (fhir.ph.core.r4)](package.r4.tgz) and [R4B (fhir.ph.core.r4b)](package.r4b.tgz) are available.



| | | |
| :--- | :--- | :--- |
| [FHIR Extensions Pack](http://hl7.org/fhir/extensions/5.2.0) | [5.2.0](https://simplifier.net/packages/hl7.fhir.uv.extensions.r4/5.2.0) |  |
| [FHIR R4 package : Core](http://hl7.org/fhir/R4) | [4.0.1](https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1) | Imported by FHIR Extensions Pack (and potentially others) |
| [HL7 Terminology (THO)](http://terminology.hl7.org/7.0.0) | [7.0.0](https://simplifier.net/packages/hl7.terminology.r4/7.0.0) |  |

*There are no Global profiles defined*

