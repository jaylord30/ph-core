# fhir.ph.core#0.2.0: Draft PH Core Implementation Guide

## Pages

* [Home](index.md)
* [PH Core Creator - JSON Representation](ActorDefinition-Creator.json.md)
* [PH Core Server](ActorDefinition-Server.md)
* [](ActorDefinition-Consumer.change.history.md)
* [PH Core Creator - TTL Representation](ActorDefinition-Creator.ttl.md)
* [Artifacts Summary](artifacts.md)
* [PH Core Server - JSON Representation](ActorDefinition-Server.json.md)
* [](ActorDefinition-Server.change.history.md)
* [PH Core Creator - XML Representation](ActorDefinition-Creator.xml.md)
* [PH Core Consumer - XML Representation](ActorDefinition-Consumer.xml.md)
* [PH Core Consumer](ActorDefinition-Consumer.md)
* [PH Core Server - TTL Representation](ActorDefinition-Server.ttl.md)
* [PH Core Consumer - TTL Representation](ActorDefinition-Consumer.ttl.md)
* [Terminology](terminology.md)
* [PH Core Server - XML Representation](ActorDefinition-Server.xml.md)
* [PH Core Consumer - JSON Representation](ActorDefinition-Consumer.json.md)
* [PH Core Server - Testing](ActorDefinition-Server-testing.md)
* [](ActorDefinition-Creator.change.history.md)
* [PH Core Creator - Testing](ActorDefinition-Creator-testing.md)
* [PH Core Creator](ActorDefinition-Creator.md)
* [Other Ids](otherIds.md)
* [PH Core Consumer - Testing](ActorDefinition-Consumer-testing.md)

## Resources

### CodeSystems

* [PH FDA Certificate of Product Registration (CPR) CodeSystem](CodeSystem-PHFDACPRCS.md)
* [Mock PSCED](CodeSystem-PSCED.md)
* [Mock PSGC](CodeSystem-PSGC.md)
* [Mock PSOC](CodeSystem-PSOC.md)
* [Indigenous Groups CodeSystem](CodeSystem-indigenous-groups-cs.md)
* [PH Core Disability Type Code System](CodeSystem-ph-core-disability-type-cs.md)

### ValueSets

* [Barangays](ValueSet-barangays.md)
* [Cities](ValueSet-cities.md)
* [Drugs](ValueSet-drugs-vs.md)
* [Educational Attainments](ValueSet-educational-attainments.md)
* [Indigenous Groups ValueSet](ValueSet-indigenous-groups-vs.md)
* [Occupation Classifications](ValueSet-occupational-classifications.md)
* [PH Core Disability Type Value Set](ValueSet-ph-core-disability-type-vs.md)
* [Provinces](ValueSet-provinces.md)
* [Regions](ValueSet-regions.md)

### Complex-type Profiles

* [PH Core Address](StructureDefinition-ph-core-address.md)
* [DOH NHFR Code](StructureDefinition-ph-core-doh-nhfr-code.md)
* [PH Core Name](StructureDefinition-ph-core-name.md)
* [PIN - PhilHealth Identification Number Identifier](StructureDefinition-ph-core-philhealth-id.md)
* [PhilHealth Accreditation Number](StructureDefinition-ph-core-philhealth-pan.md)
* [PhilHealth Employer Number](StructureDefinition-ph-core-philhealth-pen.md)
* [PhilSys Identification Number (PhilSys ID) Identifier](StructureDefinition-ph-core-philsys-id.md)

### Resource Profiles

* [PH Core AllergyIntolerance](StructureDefinition-ph-core-allergyintolerance.md)
* [PH Core Claim](StructureDefinition-ph-core-claim.md)
* [PH Core Condition](StructureDefinition-ph-core-condition.md)
* [PH Core Encounter](StructureDefinition-ph-core-encounter.md)
* [PH Core HealthcareService](StructureDefinition-ph-core-healthcareservice.md)
* [PH Core Immunization](StructureDefinition-ph-core-immunization.md)
* [PH Core Location](StructureDefinition-ph-core-location.md)
* [PH Core Medication](StructureDefinition-ph-core-medication.md)
* [PH Core Medication Administration](StructureDefinition-ph-core-medicationadministration.md)
* [PH Core Medication Dispense](StructureDefinition-ph-core-medicationdispense.md)
* [PH Core Medication Request](StructureDefinition-ph-core-medicationrequest.md)
* [PH Core Medication Statement](StructureDefinition-ph-core-medicationstatement.md)
* [PH Core Observation](StructureDefinition-ph-core-observation.md)
* [PH Core Organization](StructureDefinition-ph-core-organization.md)
* [PH Core Patient](StructureDefinition-ph-core-patient.md)
* [PH Core Practitioner](StructureDefinition-ph-core-practitioner.md)
* [PH Core PractitionerRole](StructureDefinition-ph-core-practitionerrole.md)
* [PH Core Procedure](StructureDefinition-ph-core-procedure.md)
* [PH Core Provenance](StructureDefinition-ph-core-provenance.md)
* [PH Core RelatedPerson](StructureDefinition-ph-core-relatedperson.md)
* [PH Core ServiceRequest](StructureDefinition-ph-core-serviceRequest.md)
* [PH Core Task](StructureDefinition-ph-core-task.md)

### Extensions

* [Administered Product](StructureDefinition-administered-product.md)
* [Barangay](StructureDefinition-barangay.md)
* [Batch Number](StructureDefinition-batch-number.md)
* [City/Municipality](StructureDefinition-city-municipality.md)
* [Educational Attainment](StructureDefinition-educational-attainment.md)
* [Indigenous Group](StructureDefinition-indigenous-group.md)
* [Indigenous People](StructureDefinition-indigenous-people.md)
* [Occupation](StructureDefinition-occupation.md)
* [PH Core PWD Disability Registration](StructureDefinition-ph-core-pwd-disability.md)
* [Province](StructureDefinition-province.md)
* [Race](StructureDefinition-race.md)
* [Region](StructureDefinition-region.md)

### Basics

* [Consumer](Basic-Consumer.md)
* [Creator](Basic-Creator.md)
* [Server](Basic-Server.md)

### ImplementationGuides

* [Draft PH Core Implementation Guide](index.md)

### NamingSystems

* [DOHNHFRCode](NamingSystem-DOHNHFRCodeNS.md)
* [DOHProcedureID](NamingSystem-DOHProcedureIDNS.md)
* [PhilHealthID](NamingSystem-PhilHealthIDNS.md)
* [PhilHealthPAN](NamingSystem-PhilHealthPANNS.md)
* [PhilHealthPEN](NamingSystem-PhilHealthPENNS.md)
* [PhilHealthProcedureID](NamingSystem-PhilHealthProcedureIDNS.md)
* [PhilSysID](NamingSystem-PhilSysIDNS.md)

### Examples

* [allergy-single-example (AllergyIntolerance)](AllergyIntolerance-allergy-single-example.md)
* [example-allergy (AllergyIntolerance)](AllergyIntolerance-example-allergy.md)
* [transaction-example (Bundle)](Bundle-transaction-example.md)
* [claim-single-example (Claim)](Claim-claim-single-example.md)
* [condition-single-example (Condition)](Condition-condition-single-example.md)
* [example-condition (Condition)](Condition-example-condition.md)
* [philhealth-coverage-example (Coverage)](Coverage-philhealth-coverage-example.md)
* [encounter-single-example (Encounter)](Encounter-encounter-single-example.md)
* [example-encounter (Encounter)](Encounter-example-encounter.md)
* [Outpatient Department - General Medicine (HealthcareService)](HealthcareService-healthcareservice-single-example.md)
* [example-immunization (Immunization)](Immunization-example-immunization.md)
* [immunization-single-example (Immunization)](Immunization-immunization-single-example.md)
* [Philippine General Hospital (Location)](Location-location-single-example.md)
* [example-medication (Medication)](Medication-example-medication.md)
* [medication-single-example (Medication)](Medication-medication-single-example.md)
* [medicationadministration-single-example (MedicationAdministration)](MedicationAdministration-medicationadministration-single-example.md)
* [medicationdispense-single-example (MedicationDispense)](MedicationDispense-medicationdispense-single-example.md)
* [medicationrequest-single-example (MedicationRequest)](MedicationRequest-medicationrequest-single-example.md)
* [medicationstatement-single-example (MedicationStatement)](MedicationStatement-medicationstatement-single-example.md)
* [blood-pressure (Observation)](Observation-blood-pressure.md)
* [observation-based-on-service-example (Observation)](Observation-observation-based-on-service-example.md)
* [observation-bp-example (Observation)](Observation-observation-bp-example.md)
* [observation-derived-bmi-example (Observation)](Observation-observation-derived-bmi-example.md)
* [observation-environmental-temp-example (Observation)](Observation-observation-environmental-temp-example.md)
* [observation-glucose-example (Observation)](Observation-observation-glucose-example.md)
* [observation-height-example (Observation)](Observation-observation-height-example.md)
* [observation-lab-panel-example (Observation)](Observation-observation-lab-panel-example.md)
* [observation-part-of-procedure-example (Observation)](Observation-observation-part-of-procedure-example.md)
* [observation-performer-role-example (Observation)](Observation-observation-performer-role-example.md)
* [observation-potassium-example (Observation)](Observation-observation-potassium-example.md)
* [observation-sodium-example (Observation)](Observation-observation-sodium-example.md)
* [observation-vitals-encounter-example (Observation)](Observation-observation-vitals-encounter-example.md)
* [observation-weight-example (Observation)](Observation-observation-weight-example.md)
* [Department of Health - Sattelite Office (Organization)](Organization-organization-single-example.md)
* [example-patient (Patient)](Patient-example-patient.md)
* [patient-single-example (Patient)](Patient-patient-single-example.md)
* [example-practitioner (Practitioner)](Practitioner-example-practitioner.md)
* [practitioner-single-example (Practitioner)](Practitioner-practitioner-single-example.md)
* [practitionerrole-single-example (PractitionerRole)](PractitionerRole-practitionerrole-single-example.md)
* [procedure-single-example (Procedure)](Procedure-procedure-single-example.md)
* [provenance-single-example (Provenance)](Provenance-provenance-single-example.md)
* [relatedperson-single-example (RelatedPerson)](RelatedPerson-relatedperson-single-example.md)
* [servicerequest-single-example (ServiceRequest)](ServiceRequest-servicerequest-single-example.md)
* [task-single-example (Task)](Task-task-single-example.md)
